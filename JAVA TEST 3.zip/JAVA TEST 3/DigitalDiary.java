import java.io.*;

public class DigitalDiary {

    public void writeNote(String fileName, String note) {
        try {
            File file = new File(fileName);


            if (!file.exists()) {
                file.createNewFile();
                System.out.println("Diary file created: " + fileName);
            }


            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(note);
            bw.newLine();
            bw.close();

        } catch (IOException e) {
            System.out.println("Error: Could not save note.");
        }
    }


    public void createBackup(String sourceFile, String backupFile) {
        try {
            FileReader fr = new FileReader(sourceFile);
            BufferedReader br = new BufferedReader(fr);

            FileWriter fw = new FileWriter(backupFile);
            BufferedWriter bw = new BufferedWriter(fw);

            String line;


            while ((line = br.readLine()) != null) {
                bw.write(line);
                bw.newLine();
            }

            br.close();
            bw.close();

            System.out.println("Backup created successfully: " + backupFile);

        } catch (IOException e) {
            System.out.println("Error: Could not create backup.");
        }
    }


    public static void main(String[] args) {

        DigitalDiary diary = new DigitalDiary();
        String diaryFile = "my_diary.txt";
        String backupFile = "diary_backup.txt";


        diary.writeNote(diaryFile, "Entry 1: Today I started learning Java File I/O.");
        diary.writeNote(diaryFile, "Entry 2: It was a bit confusing, but I'm getting the hang of it.");
        diary.writeNote(diaryFile, "Entry 3: I successfully created and copied a file!");


        diary.createBackup(diaryFile, backupFile);
    }
}
