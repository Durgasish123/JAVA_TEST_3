import java.util.HashMap;
public class LibraryManagementSystem {

    static class BookNotFoundException extends Exception {
        public BookNotFoundException(String message) {
            super(message);
        }
    }


    static class Book {
        private String isbn;
        private String title;
        private boolean isAvailable;

        public Book(String isbn, String title, boolean isAvailable) {
            this.isbn = isbn;
            this.title = title;
            this.isAvailable = isAvailable;
        }

        public String getIsbn() {
            return isbn;
        }

        public String getTitle() {
            return title;
        }

        public boolean isAvailable() {
            return isAvailable;
        }

        public void setAvailable(boolean available) {
            isAvailable = available;
        }
    }

    static class Library {
        private HashMap<String, Book> books = new HashMap<>();
        private int totalBooksCount = 0;

        public void addBook(Book book) {
            books.put(book.getIsbn(), book);
            if (book.isAvailable()) {
                totalBooksCount++;
            }
        }

        public void borrowBook(String isbn) throws BookNotFoundException {

            if (!books.containsKey(isbn)) {
                throw new BookNotFoundException("Book with ISBN " + isbn + " not found.");
            }

            Book book = books.get(isbn);

            if (!book.isAvailable()) {
                throw new IllegalStateException("Book is already borrowed.");
            }

            book.setAvailable(false);
            totalBooksCount--;

            System.out.println("Book borrowed successfully: " + book.getTitle());
        }

        public int getTotalBooksCount() {
            return totalBooksCount;
        }
    }

    public static void main(String[] args) {

        Library library = new Library();

        library.addBook(new Book("ISBN123", "Java Basics", true));
        library.addBook(new Book("ISBN456", "Data Structures", false));

        System.out.println("Initial totalBooksCount: " + library.getTotalBooksCount());

        try {

            library.borrowBook("ISBN123");
            System.out.println("New totalBooksCount: " + library.getTotalBooksCount());


            library.borrowBook("ISBN456");

        } catch (BookNotFoundException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (IllegalStateException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {

            library.borrowBook("ISBN999");

        } catch (BookNotFoundException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
